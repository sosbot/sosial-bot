create function luhn_generate(p_number_to_process character varying) returns character varying
    immutable
    strict
    language sql
as
$$
select luhn_generate(p_number_to_process::bigint)::varchar;
$$;

alter function luhn_generate(varchar) owner to nyrdyxoc;

