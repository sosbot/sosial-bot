create function setviewedat() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.viewedBy <> OLD.viewedBy THEN
        update messages set viewedat=now() where id=old.id;
    END IF;

    RETURN NEW;
END;
$$;

alter function setviewedat() owner to nyrdyxoc;

