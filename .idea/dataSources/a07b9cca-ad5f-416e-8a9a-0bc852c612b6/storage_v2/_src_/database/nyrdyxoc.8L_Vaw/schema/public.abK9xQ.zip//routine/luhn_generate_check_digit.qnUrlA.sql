create function luhn_generate_check_digit(p_number_to_process bigint) returns bigint
    immutable
    strict
    language sql
as
$$
SELECT
    -- Add the digits, doubling even-numbered digits (counting left
    -- with least-significant as zero). Subtract the remainder of
    -- dividing the sum by 10 from 10, and take the remainder
    -- of dividing that by 10 in turn.
    ((bigint '10' - SUM(doubled_digit / bigint '10' + doubled_digit % bigint '10') %
                    bigint '10') % bigint '10')::bigint
FROM (SELECT
          -- Extract digit `n' counting left from least significant as zero
          MOD( (p_number_to_process::bigint / (10^n)::bigint), 10::bigint )
              -- double even-numbered digits
              * (2 - MOD(n,2))
              AS doubled_digit
      FROM generate_series(0, ceil(log(p_number_to_process))::integer - 1) AS n
     ) AS doubled_digits;

$$;

alter function luhn_generate_check_digit(bigint) owner to nyrdyxoc;

