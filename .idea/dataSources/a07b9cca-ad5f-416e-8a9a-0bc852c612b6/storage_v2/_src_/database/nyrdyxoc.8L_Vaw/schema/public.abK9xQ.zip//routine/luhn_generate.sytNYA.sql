create function luhn_generate(p_number_to_process bigint) returns bigint
    immutable
    strict
    language sql
as
$$
SELECT 10 * p_number_to_process + luhn_generate_check_digit(p_number_to_process);
$$;

alter function luhn_generate(bigint) owner to nyrdyxoc;

